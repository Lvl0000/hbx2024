#!/bin/bash
while true
do
	rm lol.zip
	zip -r lol.zip *
        sleep 600
done
